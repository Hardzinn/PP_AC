/* 
* Nome: Duarte Morais de Sousa
* Número: 8220160
* Turma: LEI12T4
* 
* Nome: André Eduardo Araújo Faria 
* Número: 8220787
* Turma: LEI12T2
*/
package Exceptions;

public class EditionsWithoutSubmissionsCompleted extends Exception {

    /**
     * Creates a new instance of
     * <code>EditionsWithoutSubmissionsCompleted</code> without detail message.
     */
    public EditionsWithoutSubmissionsCompleted() {
    }

    /**
     * Constructs an instance of
     * <code>EditionsWithoutSubmissionsCompleted</code> with the specified
     * detail message.
     *
     * @param msg the detail message.
     */
    public EditionsWithoutSubmissionsCompleted(String msg) {
        super(msg);
    }
}
