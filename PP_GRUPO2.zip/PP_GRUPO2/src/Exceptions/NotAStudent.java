/* 
* Nome: Duarte Morais de Sousa
* Número: 8220160
* Turma: LEI12T4
* 
* Nome: André Eduardo Araújo Faria 
* Número: 8220787
* Turma: LEI12T2
*/
package Exceptions;

public class NotAStudent extends Exception {

    /**
     * Creates a new instance of <code>NotAStudent</code> without detail
     * message.
     */
    public NotAStudent() {
    }

    /**
     * Constructs an instance of <code>NotAStudent</code> with the specified
     * detail message.
     *
     * @param msg the detail message.
     */
    public NotAStudent(String msg) {
        super(msg);
    }
}
