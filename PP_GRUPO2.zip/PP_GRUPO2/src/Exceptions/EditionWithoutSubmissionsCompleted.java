/* 
* Nome: Duarte Morais de Sousa
* Número: 8220160
* Turma: LEI12T4
* 
* Nome: André Eduardo Araújo Faria 
* Número: 8220787
* Turma: LEI12T2
*/
package Exceptions;


public class EditionWithoutSubmissionsCompleted extends Exception {

    /**
     * Creates a new instance of <code>EditionWithoutSubmissionsCompleted</code>
     * without detail message.
     */
    public EditionWithoutSubmissionsCompleted() {
    }

    /**
     * Constructs an instance of <code>EditionWithoutSubmissionsCompleted</code>
     * with the specified detail message.
     *
     * @param msg the detail message.
     */
    public EditionWithoutSubmissionsCompleted(String msg) {
        super(msg);
    }
}
