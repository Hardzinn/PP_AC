/* 
* Nome: Duarte Morais de Sousa
* Número: 8220160
* Turma: LEI12T4
* 
* Nome: André Eduardo Araújo Faria 
* Número: 8220787
* Turma: LEI12T2
*/
package Exceptions;

public class EditionAlreadyExists extends Exception {

    /**
     * Creates a new instance of <code>EditionAlreadyExists</code> without
     * detail message.
     */
    public EditionAlreadyExists() {
    }

    /**
     * Constructs an instance of <code>EditionAlreadyExists</code> with the
     * specified detail message.
     *
     * @param msg the detail message.
     */
    public EditionAlreadyExists(String msg) {
        super(msg);
    }
}
