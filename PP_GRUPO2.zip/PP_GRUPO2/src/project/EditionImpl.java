/* 
* Nome: Duarte Morais de Sousa
* Número: 8220160
* Turma: LEI12T4
* 
* Nome: André Eduardo Araújo Faria 
* Número: 8220787
* Turma: LEI12T2
 */
package project;

import Exceptions.EditionWithoutSubmissionsCompleted;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Serializable;
import java.text.ParseException;
import java.time.LocalDate;
import ma02_resources.project.Edition;
import ma02_resources.project.Project;
import ma02_resources.project.Status;
import ma02_resources.project.Task;
import ma02_resources.project.exceptions.TaskAlreadyInProject;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class EditionImpl implements Edition, Serializable {

    private static final int MAX_ARRAY_PROJECT = 10;
    private String name;
    private LocalDate start;
    private String projectTemplate=" ";
    private Status status;
    private Project[] projects = new Project[MAX_ARRAY_PROJECT];
    private int numProjects = 0;

    public EditionImpl(String name, LocalDate start) {
        this.name = name;
        this.start = start;
        this.status = Status.INACTIVE;
    }

    /**
     * *
     * Menu de gestão de edicão
     */
    public void editionMenu() {
        System.out.println("-------------Menu de edição: " + this.name + "-------------");
        System.out.println("1.Adicionar projeto");
        System.out.println("2.Remover projeto");
        System.out.println("3.Listar projetos");
        System.out.println("4.Selecionar projeto");
        System.out.println("5.Voltar");
    }

    /**
     * *
     * Método toString que transforma uma edição em String.
     *
     * @return String
     */
    @Override
    public String toString() {
        String s = "\n--------------------";
        s += "\nNome: " + this.name;
        s += "\nInício: " + this.start.toString();
        s += "\nEstado: " + this.status.toString();
        s += this.editionProgressToString();
        s += "\n--------------------";
        return s;
    }

    /**
     * *
     * Obtém nome da edição
     *
     * @return nome da edição
     */
    @Override
    public String getName() {
        return name;
    }

    /**
     * *
     * Obtém data de inicio de uma edição
     *
     * @return data inicio
     */
    @Override
    public LocalDate getStart() {
        return start;
    }

    /**
     * *
     * Obtem o template do projecto
     *
     * @return template do projecto
     */
    @Override
    public String getProjectTemplate() {
        return projectTemplate;
    }

    /**
     * *
     * Obtém status de uma edição
     *
     * @return status de uma edição
     */
    @Override
    public Status getStatus() {
        return status;
    }

    /**
     * *
     * Define status de uma edição
     *
     * @param status Status a definir
     */
    @Override
    public void setStatus(Status status) {
        this.status = status;
    }

    /**
     * *
     * Este método faz a leitura do template fornecido em json para um projeto
     *
     * @param string nome do projeto
     * @param string1 descricao do projeto
     * @param strings tags do projeto
     * @return projeto criado a partir do template
     * @throws FileNotFoundException caso não encontre o ficheiro json
     * @throws TaskAlreadyInProject caso existam tasks repetidas no template
     * @throws IOException caso exista algum erro na leitura dos objetos no
     * ficheiro json
     * @throws org.json.simple.parser.ParseException caso exista algum erro na
     * leitura dos objetos no ficheiro json
     */
    private static ProjectImpl readTemplate(String string, String string1, String[] strings) throws FileNotFoundException, TaskAlreadyInProject, IOException, org.json.simple.parser.ParseException {
        JSONParser parser = new JSONParser();

        Object obj = parser.parse(new FileReader("./project_template.json"));

        JSONObject jsonObject = (JSONObject) obj;

        int maxFacilitators = (Math.toIntExact((long) (jsonObject.get("number_of_facilitors"))));
        int maxStudents = (Math.toIntExact((long) jsonObject.get("number_of_students")));
        int maxPartners = (Math.toIntExact((long) jsonObject.get("number_of_partners")));
        ProjectImpl project = new ProjectImpl(string, string1, strings, maxFacilitators, maxStudents, maxPartners);

        JSONArray jsonArray = (JSONArray) jsonObject.get("tasks");

        for (Object jsonObj : jsonArray) {
            TaskImp task = new TaskImp();
            JSONObject jsonItem = (JSONObject) jsonObj;
            task.setTitle((String) jsonItem.get("title"));
            task.setDescription((String) jsonItem.get("description"));
            task.setStart(LocalDate.now());  //start_at=0
            task.setDuration(Math.toIntExact((long) jsonItem.get("duration")));
            project.addTask(task);
        }

        return project;
    }

    /**
     * *
     * Este método adiciona um novo projeto à edição selecionada.
     *
     * @param string nome do projeto
     * @param string1 descricao do projeto
     * @param strings tags do projeto
     * @throws IOException se o template de projeto não for encontrado.
     * @throws ParseException se o template de projeto não for válido.
     * @throws IllegalArgumentException se o nome do projeto for nulo ou vazio,
     * se o projeto já existir
     */
    @Override
    public void addProject(String string, String string1, String[] strings) throws IOException, ParseException, IllegalArgumentException {
        ProjectImpl projectToAdd;

        if (string == null || string.isEmpty()) {
            throw new IllegalArgumentException("Nome inválido.");
        }
        if (string1 == null || string1.isEmpty()) {
            throw new IllegalArgumentException("Descrição inválida.");
        }
        if (strings[0] == null || strings[0].isEmpty()) {
            throw new IllegalArgumentException("Tags inválidas.");
        }
        if (this.searchProject(string) != -1) {
            throw new IllegalArgumentException("Já existe um projeto com esse nome.");
        }

        try {
            projectToAdd = readTemplate(string, string1, strings);
            this.projects[this.numProjects] = projectToAdd;
            this.numProjects++;
        } catch (FileNotFoundException e) {
            throw new IOException("Template não encontrado.");
        } catch (TaskAlreadyInProject ex) {
            System.out.println("Tarefas repetidas");
        } catch (org.json.simple.parser.ParseException ex) {
            throw new IOException("Template não encontrado.");
        }

    }

    /**
     * *
     * Procura um projeto pelo seu nome comparando o mesmo por todos os projetos
     * existentes no array de projetos.
     *
     * @param string Nome do Projeto a procurar
     * @return i a posição do array caso seja igual, e -1 caso não exista
     */
    private int searchProject(String string) {
        for (int i = 0; i < this.numProjects; i++) {
            if (this.projects[i].getName().compareTo(string) == 0) {
                return i;
            }
        }
        return -1;
    }

    /**
     * *
     * Método para remover um projeto numa edição.Primeiro verifica se a string
     * para procurar o projeto não está em branco. Depois utiliza o metodo
     * searchProject para procurar o projeto pelo seu nome , caso a posição não
     * seja encontrada devolve a exceção IllegalArgumentException que nos dirá
     * que o projeto não existe. Por fim o array de projetos recua uma posição
     * para apagar o projeto em causa e decrementa o numero de projetos.
     *
     * @param string Nome do projeto
     * @throws IllegalArgumentException Projeto nao encontrado
     */
    @Override
    public void removeProject(String string) throws IllegalArgumentException {

        if (string.isBlank()) {
            throw new IllegalArgumentException("Nome de projeto inválido.");
        }

        int pos = searchProject(string);

        if (pos == -1) {
            throw new IllegalArgumentException("Projeto não encontrado.");
        }

        for (int i = pos; i < this.numProjects - 1; i++) {
            this.projects[i] = this.projects[i + 1];
        }

        this.numProjects--;
    }

    /**
     * *
     * Lista todos os projetos pelo metodo toString
     */
    public void listProjects() {
        for (Project p : this.projects) {
            if (p != null) {
                System.out.println(p.toString());
            }
        }
    }

    /**
     * *
     * Obtem um projeto atraves do nome do mesmo. Percorre o array com todos os
     * projetos e verifica quais não sao nulos. Caso encontre algum com o mesmo
     * nome devolve o projeto.
     *
     * @param string Nome do projeto a procurar
     * @return O projeto desejado
     */
    @Override
    public Project getProject(String string) {
        for (Project project : projects) {
            if (project != null) {
                if (project.getName().equals(string) == true) {
                    return project;
                }
            }

        }
        throw new IllegalArgumentException("Projeto não existe");
    }

    /**
     * *
     * Obtem os projetos do array Projects
     *
     * @return projetos
     */
    @Override
    public Project[] getProjects() {
        return this.projects;
    }

    /**
     * *
     * Obtém um array com os projetos que tem uma tag especifica
     *
     * @param string Tag a procurar
     * @return array com os projetos
     */
    @Override
    public Project[] getProjectsByTag(String string) {
        int numProjectsTag = 0;
        for (Project project : this.projects) {
            if (project != null) {
                if (project.hasTag(string)) {
                    numProjectsTag++;
                }
            }
        }
        Project[] projectsTag = new Project[numProjectsTag];
        int position = 0;
        for (Project project : this.projects) {
            if (project != null) {
                if (project.hasTag(string)) {
                    projectsTag[position] = project;
                    position++;
                }
            }
        }
        return projectsTag;
    }

    /**
     * *
     * Retorna um array de projetos em que um participante específico está
     * envolvido.
     *
     * @param string O nome do participante a ser pesquisado.
     * @return Um array de projetos
     */
    @Override
    public Project[] getProjectsOf(String string) {
        int numProjectsParticipant = 0;
        for (Project project : this.projects) {
            if (project != null) {
                try {
                    project.getParticipant(string);
                    numProjectsParticipant++;
                } catch (IllegalArgumentException exc) {

                }
            }
        }
        Project[] projectsParticipant = new Project[numProjectsParticipant];
        int position = 0;
        for (Project project : this.projects) {
            if (project != null) {
                try {
                    project.getParticipant(string);
                    projectsParticipant[position] = project;
                    position++;
                } catch (IllegalArgumentException exc) {

                }
            }
        }
        return projectsParticipant;
    }

    /**
     * *
     * Obtem o numero de projetos existentes.
     *
     * @return numero de projetos
     */
    @Override
    public int getNumberOfProjects() {
        return numProjects;
    }

    /**
     * *
     * Obtem a ultima data de entrega da ultima tarefa.
     *
     * @return ultima data
     */
    @Override
    public LocalDate getEnd() {
        LocalDate end = this.start;
        for (Project p : this.projects) {
            Task[] tasks = p.getTasks();
            for (Task t : tasks) {
                if (t.getEnd().isAfter(end)) {
                    end = t.getEnd();
                }
            }
        }
        return end;
    }

    /**
     * *
     * Compara duas edições diferentes.Primeiro verifica se as duas são objetos
     * da mesma classe e depois compara os atributos das duas.
     *
     * @param obj Edição a comparar
     * @return false caso sejam diferentes, true caso sejam iguais
     */
    @Override
    public boolean equals(Object obj) {
        if (obj instanceof EditionImpl == false) {
            return false;
        }
        EditionImpl edtToCheck = (EditionImpl) obj;

        if (this.name.equals(edtToCheck.name) == false) {
            return false;
        }
        if (this.start.equals(edtToCheck.start) == false) {
            return false;
        }
        if (this.projectTemplate.equals(edtToCheck.projectTemplate) == false) {
            return false;
        }
        if (this.status.equals(edtToCheck.status) == false) {
            return false;
        }
        if (this.numProjects != edtToCheck.numProjects) {
            return false;
        }
        for (Project p : this.projects) {
            if (p != null) {
                if (edtToCheck.searchProject(p.getName()) == -1) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * *
     * Lista os projetos com submissões em falta de uma edição e da edição
     * ativa.
     *
     * @return projetos array de projetos com submissões em falta
     * @throws EditionWithoutSubmissionsCompleted Nenhum projeto com submissões em falta
     */
    public Project[] getProjectsWithMissingSubmissions() throws EditionWithoutSubmissionsCompleted {
        int index = 0;
        Project[] projs = new Project[projects.length];
        for (Project project : this.projects) {
            if (project != null) {
                if (project.isCompleted() == false) {
                    projs[index] = project;
                    index++;
                }
            }
        }
        if (index == 0) {
            throw new EditionWithoutSubmissionsCompleted("Nenhum projeto com submissões em falta.");
        } else {
            return projs;
        }
    }

    /**
     * *
     * Lista a tarefa Com a Submissão com o prazo mais perto do fim.
     *
     * @return tarefa
     */
    public Task listEditionWithSubmissionsWithLastDate() {
        Task taskWithLastSubmission = null;
        LocalDate closestDeadline = null;

        for (Project proj : projects) {
            if (proj != null) {
                Task[] task = proj.getTasks();
                for (Task t : task) {
                    if (t != null) {
                        LocalDate taskDeadline = t.getEnd();

                        if (closestDeadline == null || taskDeadline.isBefore(closestDeadline)) {
                            closestDeadline = taskDeadline;
                            taskWithLastSubmission = t;
                        }
                    }
                }
            }
        }
        return taskWithLastSubmission;
    }

    /**
     * Este método permite obter o número de projetos da edição
     *
     * @return número de projetos da edição
     */
    public int getNumProjects() {
        return this.numProjects;
    }

    /**
     * Este método obtém uma representação textual do progresso de uma edição
     *
     * @return representação textual do progresso de uma edição
     */
    public String editionProgressToString() {
        int totalTasks = 0;
        int totalTasksCompleted = 0;
        for (Project p : this.projects) {
            if (p != null) {
                totalTasks += p.getNumberOfTasks();
                Task[] tasks = p.getTasks();
                for (Task t : tasks) {
                    if (t != null) {
                        if (t.getNumberOfSubmissions() != 0) {
                            totalTasksCompleted++;
                        }
                    }
                }
            }
        }

        int projectsCompleted = 0;
        for (Project p : this.projects) {
            if (p != null) {
                if (p.isCompleted() == true) {
                    projectsCompleted++;
                }
            }
        }

        String s = "";
        s += "\nProgresso de edição:";
        s += "\n" + projectsCompleted + "/" + this.numProjects + " projetos terminados";
        s += "\n" + totalTasksCompleted + "/" + totalTasks + " tarefas terminadas";

        return s;
    }
    
}
