/* 
* Nome: Duarte Morais de Sousa
* Número: 8220160
* Turma: LEI12T4
* 
* Nome: André Eduardo Araújo Faria 
* Número: 8220787
* Turma: LEI12T2
*/

package project;

import java.io.Serializable;
import java.time.LocalDate;
import ma02_resources.project.Submission;
import ma02_resources.project.Task;


public class TaskImp implements Task, Serializable {

    private static final int SUBMISSIONS_NUMBER = 15;
    private static final int DOUBLE = 2;

    private String title;
    private String description;
    private LocalDate start;
    private int duration;
    private Submission[] submissions = new Submission[SUBMISSIONS_NUMBER];
    private int numberOfSubmissions = 0;

    public TaskImp(String title, String description, LocalDate startAt, int duration) {
        this.title = title;
        this.description = description;
        this.start = startAt;
        this.duration = duration;
    }

    public TaskImp(String title, String description, LocalDate startAt, int duration,Submission[] submissions) {
        this.title = title;
        this.description = description;
        this.start = startAt;
        this.submissions = submissions;
        this.duration = duration;
    }
    
    public TaskImp() {
    }

    public void taskMenu() {
        System.out.println("-------------Menu de tarefa: " + this.title + "-------------");
        System.out.println("1.Adicionar submissão");
        System.out.println("2.Listar submissões");
        System.out.println("3.Alterar duração");
        System.out.println("4.Voltar");
    }

    @Override
    public String toString() {
        String s = "\n----------Tarefa----------";
        s += "\nTitulo : " + this.title;
        s += "\nDescrição : " + this.description;
        s += "\nDuração : " + this.duration;
        s += "\nData de início : " + this.start.toString();
        s += "\nData limite : " + this.getEnd().toString();
        s += "\nNªSubmissões : " + this.numberOfSubmissions;
        return s;
    }

    /***
     * Método que lista todas as submissões não nulas que existem no array de submissões
     * Imprime as submissões no ecra do utilizador.
     */
    public void listSubmissions() {
        for (Submission s : this.submissions) {
            if (s != null) {
                System.out.println(submissions.toString());
            }
        }
    }

    /***
     * Obtém o titulo de uma tarefa.
     * @return o titulo da tarefa.
     */
    @Override
    public String getTitle() {
        return title;
    }
    
    /***
     * Define o titulo de uma tarefa
     * @param title String do titulo que desejamos colocar na tarefa.
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /***
     * Obtém a descrição de uma tarefa em especifico
     * @return a descrição
     */
    @Override
    public String getDescription() {
        return description;
    }

    /***
     * Define a descrição de uma tarefa em especifico
     * @param description String da descrição que desejamos colocar na tarefa.
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /***
     * Obtém a data em que a tarefa foi inicializada.
     * @return a data da tarefa.
     */
    @Override
    public LocalDate getStart() {
        return start;
    }

    /***
     * Define a data do inicio de uma tarefa.
     * @param start a data da tarefa.
     */
    public void setStart(LocalDate start) {
        this.start = start;
    }

    /***
     * Método que calcula o fim de uma tarefa, 
     * através da data de inicio e a duracao da tarefa.
     * @return a data do fim da tarefa.
     */
    @Override
    public LocalDate getEnd() {
        LocalDate end = this.start.plusDays(duration);
        return end;
    }

    /***
     * Obtém a duração de uma tarefa.
     * @return a duração da tarefa.
     */
    @Override
    public int getDuration() {
        return duration;
    }

    /***
     * Define a duração de uma tarefa
     * @param duration numero de dias que definem a duração
     */
    public void setDuration(int duration) {
        this.duration = duration;
    }

    /***
     * Obtém a referencia de um de array de submissões 
     * @return o array de submissões
     */
    @Override
    public Submission[] getSubmissions() {
        return submissions;
    }

    /***
     * Define um array de submissões nas tarefas.
     * @param submissions array de submissões
     */
    public void setSubmission(Submission[] submissions) {
        this.submissions = submissions;
    }
    
    /***
     * Obtem número total de submissões
     * @return o numero de submissões
     */
    @Override
    public int getNumberOfSubmissions() {
        return numberOfSubmissions;
    }

    /***
     * Expande o array de submissões para o dobro. 
     * Para isso é criado um array temporário em que é armazenado 
     * todas as submissoes que estavam armazenada no array antigo
     * e depois de passar todas as submissões o array temporário passa 
     * para o array original, com o dobro do tamanho como desejado.
     */
    private void expandSubmissionArray() {
        Submission[] submissionTemp = new Submission[DOUBLE * SUBMISSIONS_NUMBER];

        for (int i = 0; i < this.numberOfSubmissions; i++) {
            submissionTemp[i] = this.submissions[i];
        }

        this.submissions = submissionTemp;

    }
    
    /***
     * Método que adiciona uma submissão ao array de submissões.
     * Caso o array já esteja cheio, este aumenta em 2x o seu tamanho.
     * Caso a submissão a adicionar seja null, o sistema devolver uma exceção 
     * e diz que não foi possivel adicionar a mesma.
     * No fim aumenta ao numero de submissões.
     * @param sbmsn submissão a ser adicionada
     */
    @Override
    public void addSubmission(Submission sbmsn) {
        if (this.numberOfSubmissions == this.submissions.length) {
            expandSubmissionArray();
        }

        this.submissions[this.numberOfSubmissions] = sbmsn;

        if (this.submissions[this.numberOfSubmissions] == null) {
            throw new IllegalArgumentException("Não foi possivel adicionar.");
        }

        this.numberOfSubmissions++;

    }

    /***
     * Método que extende o limite de uma tarefa aumentar a duração da mesma 
     * com os dias que desejam extender a tarefa.
     * @param i numero de dias que desejamos aumentar a deadLine.
     * @throws IllegalArgumentException valor de dias inserido inválido
     */
    @Override
    public void extendDeadline(int i) throws IllegalArgumentException {
        if (i < 0) {
            throw new IllegalArgumentException("Número de dias inseridos negativo.");
        } else {
            this.duration += i;
        }
    }

    /***
     * Método para compara Tarefas. Verifica se o obj a passar é de instancia de TaskImp
     * e compara os atributos de uma tarefa com a tarefa que desejamos comparar.
     * @param obj Tarefa que desejamos comparar
     * @return false caso não seja iguais, e true caso os dois objetos sejam iguais.
     */
    @Override
    public boolean equals(Object obj) {
        if (obj instanceof TaskImp == false) {
            return false;
        }
        TaskImp objToCheck = (TaskImp) obj;
        if (objToCheck.title.equals(this.title) == false) {
            return false;
        }
        if (objToCheck.description.equals(this.description) == false) {
            return false;
        }
        if (objToCheck.start.isEqual(this.start) == false) {
            return false;
        }
        if (objToCheck.duration != this.duration) {
            return false;
        }
        if (objToCheck.numberOfSubmissions != this.numberOfSubmissions) {
            return false;
        }
        for (int i = 0; i < this.numberOfSubmissions; i++) {
            if (objToCheck.findSubmission(this.submissions[i]) == null) {
                return false;
            }
        }
        return true;
    }

    /***
     * Este método compara as datas de duas tarefas diferentes para analisar
     * qual é a mais antiga , recente ou se são as duas do mesmo dia.
     * @param task Tarefa a comparar
     * @return 0 caso as duas começaram no mesmo dia, 
     * 1 se a tarefa a comparar for mais antiga e -1 caso for mais recente.
     */
    @Override
    public int compareTo(Task task) {
        if (this.getStart().isEqual(task.getStart())) {
            return 0;
        } else if (this.getStart().isAfter(task.getStart())) {
            return 1;
        } else {
            return -1;
        }
    }

    /**
     * Este método procura por uma submissão no array de submissões
     * @param subToFind Submissao que desejamos encontrar.
     * @return Referencia da submissao desejada, caso contrário returna null
     */
    public Submission findSubmission(Submission subToFind) {
        for (Submission sub : submissions) {
            if (subToFind.equals(sub)) {
                return sub;
            }
        }
        return null;
    }
}
