/* 
* Nome: Duarte Morais de Sousa
* Número: 8220160
* Turma: LEI12T4
* 
* Nome: André Eduardo Araújo Faria 
* Número: 8220787
* Turma: LEI12T2
*/

package project;

import Exceptions.EditionAlreadyExists;
import java.io.Serializable;
import ma02_resources.project.Edition;


public interface EditionManagement extends Serializable {

    public Edition[] getEditions();

    public void addEdition(Edition e) throws EditionAlreadyExists;

    public void deleteEditon(String edName);

    public void setActiveEdition(String edName);
}
