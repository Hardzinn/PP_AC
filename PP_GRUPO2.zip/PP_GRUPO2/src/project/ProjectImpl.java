/* 
* Nome: Duarte Morais de Sousa
* Número: 8220160
* Turma: LEI12T4
* 
* Nome: André Eduardo Araújo Faria 
* Número: 8220787
* Turma: LEI12T2
 */
package project;

import Exceptions.NotAStudent;
import Exceptions.TagAlreadyInProject;
import java.io.Serializable;
import java.time.LocalDate;
import ma02_resources.participants.Facilitator;
import ma02_resources.participants.Instituition;
import ma02_resources.participants.Participant;
import ma02_resources.participants.Partner;
import ma02_resources.participants.Student;
import ma02_resources.project.Project;
import ma02_resources.project.Task;
import ma02_resources.project.exceptions.IllegalNumberOfParticipantType;
import ma02_resources.project.exceptions.ParticipantAlreadyInProject;
import ma02_resources.project.exceptions.TaskAlreadyInProject;

public class ProjectImpl implements Project, Serializable {

    private static final int ARRAY_NUMBER = 10;
    private String name;
    private String description;
    private Task[] tasks = new Task[ARRAY_NUMBER];
    private int numTasks = 0;
    private Participant[] participants;
    private int numberOfParticipants;
    private int numberOfFacilitators;
    private int numberOfStudents;
    private int numberOfPartners;
    private int maxTasks;
    private int maxParticipants;
    private int maxStudents;
    private int maxPartners;
    private int maxFacilitators;
    private int numTags;
    private String[] tags = new String[5];

    public ProjectImpl(String name, String description, String[] tags, int maxFacilitators, int maxStudents, int maxPartners) {
        this.name = name;
        this.description = description;
        for (String tag : tags) {
            if (tag != null) {
                try {
                    this.addTag(tag);
                } catch (TagAlreadyInProject exc) {
                    System.out.println(exc.getMessage());
                }
            }
        }
        this.maxFacilitators = maxFacilitators;
        this.maxStudents = maxStudents;
        this.maxPartners = maxPartners;
        this.maxParticipants = maxFacilitators + maxStudents + maxPartners;
        participants = new Participant[this.maxParticipants];
    }

    /**
     * *
     * Projecto em string
     *
     * @return string das informações do projeto
     */
    @Override
    public String toString() {
        String s = "\n--------------------";
        s += "\nNome do projeto: " + this.name;
        s += "\nDescrição do projeto: " + this.description;
        s += "\nNumero de tarefas: " + this.numTasks;
        s += "\nNumero de participantes: " + this.numberOfParticipants;
        s += this.projectProgressToString();
        s += "\n--------------------";

        return s;
    }

    /**
     * *
     * Menu para gerir projetos
     */
    public void projectMenu() {
        System.out.println("-------------Menu de projeto: " + this.name + "-------------");
        System.out.println("1.Tarefas");
        System.out.println("2.Participantes");
        System.out.println("3.Tags");
        System.out.println("4.Top tarefas com datas limite mais próximas");
        System.out.println("5.Voltar");
    }

    /**
     * *
     * Menu para gerir tarefas
     */
    public void taskManagementMenu() {
        System.out.println("-------------Tarefas de: " + this.name + "-------------");
        System.out.println("1.Adicionar tarefa");
        //System.out.println("2.Remover tarefa");
        System.out.println("2.Listar tarefas");
        System.out.println("3.Selecionar tarefa");
        System.out.println("4.Voltar");
    }

    /**
     * *
     * Método para listar tarefas
     */
    public void listTasks() {
        for (Task t : this.tasks) {
            if (t != null) {
                System.out.println(t.toString());
            }
        }
    }

    /**
     * *
     * Menu para gerir participantes
     */
    public void participantManagementMenu() {
        System.out.println("-------------Participantes de: " + this.name + "-------------");
        System.out.println("1.Adicionar participante");
        System.out.println("2.Remover participante");
        System.out.println("3.Listar participantes");
        System.out.println("4.Selecionar participante");
        System.out.println("5.Voltar");
    }

    /**
     * *
     * Lista todos os participantes de um projecto. Para tal percorre o array de
     * participantes e verifica os que não são nulos
     */
    public void listParticipants() {
        for (Participant p : this.participants) {
            if (p != null) {
                System.out.println(p.toString());
            }
        }
    }

    /**
     * *
     * Menu para Gerir Tags
     */
    public void tagsManagementMenu() {
        System.out.println("-------------Tags de: " + this.name + "-------------");
        System.out.println("1.Adicionar tag");
        System.out.println("2.Remover tag");
        System.out.println("3.Listar tags");
        System.out.println("4.Voltar");
    }

    /**
     * *
     * Lista as tags existentes num projeto. Para tal percurre o array de tags e
     * e verifica pelas tags que não são nulas.
     */
    public void listTags() {
        System.out.println("Tags do projeto " + this.name + ":");
        for (String t : this.tags) {
            if (t != null) {
                System.out.println(t);
            }
        }
    }

    /**
     * *
     * Obtém o nome do projeto
     *
     * @return nome do projeto
     */
    @Override
    public String getName() {
        return name;
    }

    /**
     * *
     * Obtém a descrição de um projeto
     *
     * @return a descrição
     */
    @Override
    public String getDescription() {
        return description;
    }

    /**
     * *
     * Obtém o numero de participantes existentes
     *
     * @return numero de participantes
     */
    @Override
    public int getNumberOfParticipants() {
        return numberOfParticipants;
    }

    /**
     * *
     * Obtém o numero de estudantes existentes
     *
     * @return numero de estudantes
     */
    @Override
    public int getNumberOfStudents() {
        return numberOfStudents;
    }

    /**
     * *
     * Obtém o numero de partners existentes
     *
     * @return numero de partners
     */
    @Override
    public int getNumberOfPartners() {
        return numberOfPartners;
    }

    /**
     * *
     * Obtém o numero de facilitadores existentes
     *
     * @return numero de facilitadores
     */
    @Override
    public int getNumberOfFacilitators() {
        return numberOfFacilitators;
    }

    /**
     * *
     * Obtém o numero de tarefas existentes
     *
     * @return numero de tarefas
     */
    @Override
    public int getNumberOfTasks() {
        return numTasks;
    }

    /**
     * *
     * Obtém o numero Maximo de tarefas
     *
     * @return numero Maximo de tarefas
     */
    @Override
    public int getMaximumNumberOfTasks() {
        return maxTasks;
    }

    /**
     * *
     * Obtém o numero Maximo de participantes
     *
     * @return numero Maximo de participantes
     */
    @Override
    public long getMaximumNumberOfParticipants() {
        return maxParticipants;
    }

    /**
     * *
     * Obtém o numero Maximo de estudantes
     *
     * @return numero Maximo de estudantes
     */
    @Override
    public int getMaximumNumberOfStudents() {
        return maxStudents;
    }

    /**
     * *
     * Obtém o numero Maximo de Partners
     *
     * @return numero Maximo de Partners
     */
    @Override
    public int getMaximumNumberOfPartners() {
        return maxPartners;
    }

    /**
     * *
     * Obtém o numero Maximo de facilitadores
     *
     * @return numero Maximo de facilitadores
     */
    @Override
    public int getMaximumNumberOfFacilitators() {
        return maxFacilitators;
    }

    /**
     * *
     * Procura por um participante igual ao participante no array de
     * participante
     *
     * @param p Participante a adicionar
     * @return true caso exista, false caso não exista
     */
    private boolean searchParticipant(Participant p) {
        for (int i = 0; i < this.numberOfParticipants; i++) {
            if (this.participants[i].equals(p)) {
                return true;
            }
        }
        return false;
    }

    /**
     * *
     * Procura um participante pelo seu email.
     *
     * @param email
     * @return i a posição do pasticipante no array, ou -1 caso não exista
     */
    private int searchParticipantByEmail(String email) {
        for (int i = 0; i < this.numberOfParticipants; i++) {
            if (this.participants[i].getEmail().compareTo(email) == 0) {
                return i;
            }
        }
        return -1;
    }

    /**
     * *
     * Adiciona um participante ao projeto, para tal verifica se o participante
     * já existe ou se o numero de participantes permitidos num projeto ainda
     * nao chegou ao limite.Caso o estas condições se confirmem o participante a
     * adicionior, é adicionada ao array e o numero de participantes é
     * incrementado.
     *
     * @param p participante a adicionar
     * @throws ParticipantAlreadyInProject se o participante já existir
     * @throws IllegalNumberOfParticipantType se o número máximo de participantes ed um determinado tipo já tiver sido atingido
     */
    @Override
    public void addParticipant(Participant p) throws ParticipantAlreadyInProject, IllegalNumberOfParticipantType {

        if (this.searchParticipantByEmail(p.getEmail()) != -1) {
            throw new ParticipantAlreadyInProject("Participante já existe neste projeto.");
        }

        if (this.numberOfParticipants == this.maxParticipants) {
            throw new IllegalNumberOfParticipantType("Máximo de participantes no projeto atingido.");
        }

        if (p instanceof Student) {
            if (numberOfStudents == maxStudents) {
                throw new IllegalNumberOfParticipantType("Máximo de estudantes no projeto atingido.");
            }
            numberOfStudents++;
        }

        if (p instanceof Facilitator) {
            if (numberOfFacilitators == maxFacilitators) {
                throw new IllegalNumberOfParticipantType("Máximo de facilitadores no projeto atingido.");
            }
            numberOfFacilitators++;
        }

        if (p instanceof Partner) {
            if (numberOfPartners == maxPartners) {
                throw new IllegalNumberOfParticipantType("Máximo de parceiros no projeto atingido.");
            }
            numberOfPartners++;
        }

        this.participants[this.numberOfParticipants] = p;
        this.numberOfParticipants++;

    }

    /**
     * *
     * Método para remover um participante do array de participantes. Primeiro
     * procura pelo participante para ver se existe caso exista move o array dos
     * participantes em uma posição para eliminar o conteudo do participante que
     * queremos eliminar.No fim decremenata o numero de participantes.
     *
     * @param string Email do participante a eliminar
     * @return participante a remover
     * @throws IllegalArgumentException se o participante procurado não for encontrado
     */
    @Override
    public Participant removeParticipant(String string) throws IllegalArgumentException {
        int position = searchParticipantByEmail(string);

        if (position != -1) {
            for (int i = position; i < this.numberOfParticipants - 1; i++) {
                this.participants[i] = this.participants[i + 1];
            }
        } else {
            throw new IllegalArgumentException("O participante que procura não existe.");
        }
        this.numberOfParticipants--;
        Participant participantToRemove = this.participants[position];
        return participantToRemove;
    }

    /**
     * *
     * Procura por um participante pelo email.
     *
     * @param string email do estudante a comparar
     * @return o participante em especifico
     * @throws IllegalArgumentException se o participante procurado não for encontrado
     */
    @Override
    public Participant getParticipant(String string) throws IllegalArgumentException {
        int position = searchParticipantByEmail(string);

        if (position == -1) {
            throw new IllegalArgumentException("O participante que procura não existe.");
        }

        return this.participants[position];

    }

    /**
     * *
     * Procura por um estudante através do email .
     *
     * @param string email do estudante a comparar
     * @return o estudante que queriamos.
     * @throws IllegalArgumentException se o participante não for encontrado
     * @throws NotAStudent Não é um estudante
     */
    public Student findStudent(String string) throws IllegalArgumentException, NotAStudent {
        Participant participantToFind = this.getParticipant(string);

        if (participantToFind instanceof Student) {
            return (Student) participantToFind;
        }

        throw new NotAStudent("O email que inseriu não é de um estudante.");
    }

    /**
     * *
     * Extende o array de tags para o dobro. Para isso cria um array Temporário
     * e transfere todas as tags para esse array, no final igualamos o array
     * Temporário ao array original e assim ele fica o dobro do tamanho.
     */
    protected void extendTags() {
        String[] newTags = new String[2 * this.tags.length];

        for (int i = 0; i < this.numTags; i++) {
            newTags[i] = this.tags[i];
        }

        this.tags = newTags;
    }

    /**
     * *
     * Método para adicionar uma tag ao array de tags. Caso o numero de tags
     * seja igual ao tamanho do array, o array de tags aumenta 2x. Caso essa tag
     * já exista no array o programa não deixa prosseguir lançando uma exceção
     *
     * @param tag a adicionar
     * @throws TagAlreadyInProject Exceção caso a tag já exista
     */
    public void addTag(String tag) throws TagAlreadyInProject {
        if (this.numTags == this.tags.length) {
            this.extendTags();
        }

        if (this.hasTag(tag) == true) {
            throw new TagAlreadyInProject("Tag já existe.");
        } else {
            this.tags[this.numTags] = tag;
            this.numTags++;
        }
    }

    /**
     * *
     * Método para eliminar uma tag no array de Strings que contém as tags.
     * Primeiro utiliza o método searchTag para procurar se a tag a eliminar
     * existe no array Com isso conseguimos a posicação da tag no array e
     * eliminamos essa tag ao percurremos o array e adiantamos o array em 1 . No
     * fim decrementamos o numero de tags e dizemos que a ultima posiçao do
     * array que tinha informações é null para eliminarmos qualquer conteudo que
     * lá exista.
     *
     * @param tagToDelete tag que vai ser eliminada
     * @throws IllegalArgumentException tag não encontrada
     */
    public void deleteTag(String tagToDelete) throws IllegalArgumentException {
        int position = this.searchTag(tagToDelete);

        for (int i = position; i < this.numTags - 1; i++) {
            this.tags[i] = this.tags[i + 1];
        }

        this.numTags--;
        this.tags[numTags] = null;

        System.out.println("Tag " + tagToDelete + " apagada.");
    }

    /**
     * *
     * Obtém o array de Strings com as tags
     *
     * @return tags
     */
    @Override
    public String[] getTags() {
        return tags;
    }

    /**
     * *
     * Verifica no array de tags se a tag a procurar existe no mesmo.
     *
     * @param string Tag a comparar
     * @return true caso tenha a tag no array, false caso não exista.
     */
    @Override
    public boolean hasTag(String string) {
        for (String tag : tags) {
            if (tag != null) {
                if (tag.compareTo(string) == 0) {
                    return true;
                }
            }
        }
        return false;

    }

    /**
     * *
     * Procura por uma Tag no array de Tags, para tal, compara a String com as
     * tags que estão no array de tags.
     *
     * @param string Tag a procurar
     * @return i posição da tag no array
     * @throws IllegalArgumentException quando não existe nenhuma tag igual no
     * array
     */
    public int searchTag(String string) throws IllegalArgumentException {
        for (int i = 0; i < this.numTags; i++) {
            if (tags[i].compareTo(string) == 0) {
                return i;
            }
        }
        throw new IllegalArgumentException("Tag não encontrada.");

    }

    /**
     * *
     * Procura uma tarefa no array de tarefas, para isso compara com todas as
     * tarefas no array de tarefas .
     *
     * @param task Tarefa a procurar
     * @return true caso exista, false caso não exista.
     */
    private boolean searchTask(Task task) {
        for (int i = 0; i < this.numTasks; i++) {
            if (this.tasks[i].equals(task)) {
                return true;
            }
        }
        return false;
    }

    /**
     * *
     * Extende o array de tarefas para o dobro. É criado primeiro um array
     * temporário e depois copiamos todas as tarefas para o array temporário.
     * Finalmente atribuimos que o arrayTemporário seja igual ao array original
     * e assim o array original é aumentado para o dobro
     */
    private void extendTasks() {
        Task[] taskstemp = new Task[2 * this.tasks.length];

        for (int i = 0; i < this.numTasks; i++) {
            taskstemp[i] = this.tasks[i];
        }

        this.tasks = taskstemp;
    }

    /**
     * *
     * Adiciona tarefas ao array de tarefas, caso o numero de tarefas for o
     * mesmo ao tamanho do array das tarefas, o array aumenta para o dobro. Caso
     * a tarefa já exista o sistema mostra uma exceção. Caso seja bem sucedida,
     * a tarefa é incrementada no numero de tarefas, e é adicionada no array.
     *
     * @param task tarefa a ser adicionada
     * @throws TaskAlreadyInProject tarefa já existe
     */
    @Override
    public void addTask(Task task) throws TaskAlreadyInProject {

        if (this.numTasks == this.tasks.length) {
            this.extendTasks();
        }

        if (this.searchTask(task) == true) {
            throw new TaskAlreadyInProject("Tarefa já existe.");
        } else {
            this.tasks[this.numTasks] = task;
            this.numTasks++;
        }

    }

    /**
     * *
     * Procura a tarefa pelo nome, percurrendo o array de tarefas ate ao ultimo
     * numero de tarefas existente
     *
     * @param string Nome da tarefa que queremos procurar no array
     * @return i número da posição da tarefa, ou -1 caso não exista
     */
    private int searchTaskByName(String string) {
        for (int i = 0; i < this.numTasks; i++) {
            if (this.tasks[i].getTitle().compareTo(string) == 0) {
                return i;
            }
        }
        return -1;
    }

    /**
     * *
     * Obtém a tarefa, procurando-a pelo nome da mesma, caso posição for = -1
     * significa que a tarefa não existe ou não foi encontrada.
     *
     * @param string Nome da tarefa
     * @return a tarefa
     * @throws IllegalArgumentException Tarefa nao encontrada, ou simplesmente
     * não existe
     */
    @Override
    public Task getTask(String string) throws IllegalArgumentException {
        int position = searchTaskByName(string);
        if (position == -1) {
            throw new IllegalArgumentException("Tarefa não encontrada.");
        }
        return this.tasks[position];
    }

    /**
     * *
     * Obtém o array de tarefas
     *
     * @return as tarefas
     */
    @Override
    public Task[] getTasks() {
        return tasks;
    }

    /**
     * *
     * Analisa no array de tarefas se o numero de submissoes for igual a 0
     * significa que a tarefa não esta completa, caso esteja completa o numero
     * de submissoes tem de ser diferente de 0
     *
     * @return false caso esteja completa, true o contrario
     */
    @Override
    public boolean isCompleted() {
        for (Task task : tasks) {
            if (task != null) {
                if (task.getNumberOfSubmissions() == 0) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * *
     * Compara dois projetos diferentes. Primeiro verifica se são os dois
     * objetos da mesma classe e depois compara os diferentes atribuitos.
     *
     * @param obj Projecto que queremos comparar
     * @return false caso seja diferente, e true caso sejam iguais
     */
    @Override
    public boolean equals(Object obj) {
        if (obj instanceof ProjectImpl == false) {
            return false;
        }
        ProjectImpl objToCheck = (ProjectImpl) obj;
        if (this.name.equals(objToCheck.name) == false) {
            return false;
        }
        if (this.description.equals(objToCheck.description) == false) {
            return false;
        }
        if (this.numTasks != objToCheck.numTasks) {
            return false;
        }
        if (this.maxTasks != objToCheck.maxTasks) {
            return false;
        }
        for (Task task : objToCheck.tasks) {
            if (task != null) {
                if (this.searchTask(task) == false) {
                    return false;
                }
            }
        }
        if (this.numberOfParticipants != objToCheck.numberOfParticipants) {
            return false;
        }
        if (this.maxParticipants != objToCheck.maxParticipants) {
            return false;
        }
        if (this.numberOfFacilitators != objToCheck.numberOfFacilitators) {
            return false;
        }
        if (this.maxFacilitators != objToCheck.maxFacilitators) {
            return false;
        }
        if (this.numberOfStudents != objToCheck.numberOfStudents) {
            return false;
        }
        if (this.maxStudents != objToCheck.maxStudents) {
            return false;
        }
        if (this.numberOfPartners != objToCheck.numberOfPartners) {
            return false;
        }
        if (this.maxPartners != objToCheck.maxPartners) {
            return false;
        }
        for (Participant participant : objToCheck.participants) {
            if (participant != null) {
                if (this.searchParticipant(participant) == false) {
                    return false;
                }
            }
        }
        for (String tag : objToCheck.tags) {
            if (tag != null) {
                if (this.hasTag(tag) == false) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * *
     * Método que procura uma instituição de um participante que esteja no array
     * de participantes. Atraves de equalsIgnoreCase compara o nome da
     * instituição com a instuição que queremos comparar.
     *
     * @param string Nome da instituição que queremos comparar
     * @return a instituição que queremos, ou null caso não exista/nao seja
     * igual
     */
    public Instituition findInstituition(String string) {
        for (Participant p : this.participants) {
            if (p != null) {
                if (p.getInstituition().getName().equalsIgnoreCase(string) == true) {
                    return p.getInstituition();
                }
            }
        }
        return null;
    }

    /**
     * Este método obtém uma representação textual do progresso de um projeto
     *
     * @return representação textual do progresso de um projeto
     */
    public String projectProgressToString() {
        int numCompleted = 0;

        for (Task t : this.tasks) {
            if (t != null) {
                if (t.getNumberOfSubmissions() != 0) {
                    numCompleted++;
                }
            }
        }

        String s = "";
        s = "\nProgresso de projeto: " + numCompleted + "/" + this.numTasks + " tarefas completas";
        return s;
    }

    /**
     * Lista tarefas com data limite mais próxima
     */
    public void listClosestDeadlineTasks() {
        LocalDate closestDate = LocalDate.MAX;
        LocalDate topClosestDate = LocalDate.MAX;

        for (int i = 0; i < 10; i++) {
            closestDate = LocalDate.MAX;
            for (int j = 0; j < this.numTasks; j++) {

                if (i == 0) {
                    if (this.tasks[j].getEnd().isBefore(closestDate)) {
                        closestDate = this.tasks[j].getEnd();
                    }
                } else {
                    if (this.tasks[j].getEnd().isBefore(closestDate) && topClosestDate.isBefore(this.tasks[j].getEnd())) {
                        closestDate = this.tasks[j].getEnd();
                    }
                }
            }
            for (Task t : this.tasks) {
                if (t != null) {
                    if (t.getEnd().equals(closestDate) && (topClosestDate.equals(closestDate) == false)) {
                        System.out.println("\n\n" + (i + 1) + "º data limite mais próxima");
                        System.out.println("\nData limite: " + closestDate.toString());
                        System.out.println(t.toString());
                    }
                }
            }
            topClosestDate = closestDate;
        }
    }
}
