/* 
* Nome: Duarte Morais de Sousa
* Número: 8220160
* Turma: LEI12T4
* 
* Nome: André Eduardo Araújo Faria 
* Número: 8220787
* Turma: LEI12T2
 */
package project;

import Exceptions.EditionAlreadyExists;
import Exceptions.EditionNotFound;
import Exceptions.EditionsWithoutSubmissionsCompleted;
import Exceptions.InstituitionNotFound;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.time.LocalDate;
import ma02_resources.participants.Instituition;
import ma02_resources.project.Edition;
import ma02_resources.project.Project;
import ma02_resources.project.Status;
import ma02_resources.project.Task;
import main.Input;

public class EditionManagementImpl implements EditionManagement, Serializable {

    private static final int MAX_ARRAY_EDITION = 10;
    private Edition[] editions = new Edition[MAX_ARRAY_EDITION];
    private int numEditions=0;
    private Edition activeEdition;

    /**
     * *
     * Menu de gestão de edições
     *
     * @return a opção selecionada
     */
    public int managementMenu() {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int opt = 0;
        String str;
        System.out.println("-------------------------Menu inicial-------------------------");
        System.out.println("1.Adicionar edição.");
        System.out.println("2.Remover edição.");
        System.out.println("3.Definir edição ativa.");
        System.out.println("4.Listar edições");
        System.out.println("5.Selecionar edição");
        System.out.println("6.Top de edições com mais participantes");
        System.out.println("7.Top de edições com mais projetos");
        System.out.println("8.Guardar");
        System.out.println("9.Sair");

        opt = Input.inputInt();

        return opt;
    }

    /**
     * *
     * Obtém o array de edicões
     *
     * @return array de edicões
     */
    @Override
    public Edition[] getEditions() {
        return editions;
    }

    /**
     * *
     * Define o array de edições
     *
     * @param editions array de edições
     */
    public void setEditions(Edition[] editions) {
        this.editions = editions;
    }

    /**
     * *
     * Obtém o número de edições
     *
     * @return número de edições
     */
    public int getNumEditions() {
        return numEditions;
    }

    /**
     * *
     * Obtém a edição ativa
     *
     * @return edição ativa
     */
    public Edition getActiveEdition() {
        return activeEdition;
    }

    /**
     * *
     * Define a edição ativa, procurando a edição pelo nome, caso exista de
     * verdade define a edição como ativa e guarda a edição como a atual edição
     * ativa.
     *
     * @param edName nome da edição a ativar
     */
    @Override
    public void setActiveEdition(String edName) {

        int position = findEditionByName(edName);
        if (position != -1) {
            if (this.activeEdition != null) {
                this.activeEdition.setStatus(Status.INACTIVE);
            }
            this.editions[position].setStatus(Status.ACTIVE);
            this.activeEdition = this.editions[position];
        } else {
            System.out.println("Edição não encontrada.");
        }
    }

    /**
     * *
     * Obtém uma edição pelo nome da mesma, utiliza o método findEditionByName
     * para procurar se esta existe, e caso exista obtém a edição desejada
     *
     * @param name Nome da edição
     * @return a edição
     * @throws EditionNotFound Edição não encontrada
     */
    public Edition getEdition(String name) throws EditionNotFound {
        int position = this.findEditionByName(name);
        if (position != -1) {
            return this.editions[position];
        } else {
            throw new EditionNotFound("Edição não encontrada");
        }
    }

    /**
     * *
     * Encontra uma edição no array de edições que seja igual há desejada.
     *
     * @param edToFind Edição procurada
     * @return edição caso exista, null caso nao exista
     */
    public Edition findEdition(Edition edToFind) {
        for (Edition ed : editions) {
            if (ed != null) {
                if (ed.equals(edToFind)) {
                    return ed;
                }
            }
        }
        return null;
    }

    /**
     * *
     * Encontra uma edição no array de edições pelo o nome da mesma. Procura no
     * array tudo e compara o nome da edição.
     *
     * @param name
     * @return 1 caso encontre uma edição com o mesmo nome, -1 caso não exista
     */
    private int findEditionByName(String name) {
        for (int i = 0; i < this.numEditions; i++) {
            if (this.editions[i].getName().equals(name) == true) {
                return i;
            }
        }
        return -1;
    }

    /**
     * *
     * Expande o array de edições para o dobro do mesmo. Cria um array
     * temporário e guarda todas as informações do array anterior no temporário.
     * No fim igualamos o temporário ao original para que este fique com todas
     * as edições mas com o dobro do tamanho
     */
    private void extendEdition() {
        Edition[] editionTemp = new Edition[2 * this.editions.length];

        for (int i = 0; i < this.numEditions; i++) {
            editionTemp[i] = this.editions[i];
        }

        this.editions = editionTemp;
    }

    /**
     * *
     * Adiciona uma edição ao array de edições. Caso o numero de edições seja
     * igual ao tamanho do array este expande para o dobro. Procura a edição no
     * array para ver se encontra uma igual, caso não encontre passa a edição
     * para o array e incrementa o numero de edições
     *
     * @param e Edição a adicionar
     * @throws EditionAlreadyExists Edição já existe
     */
    @Override
    public void addEdition(Edition e) throws EditionAlreadyExists {

        if (this.numEditions == this.editions.length) {
            this.extendEdition();
        }

        if (this.findEditionByName(e.getName()) == -1) {
            this.editions[this.numEditions] = e;
            this.numEditions++;
        } else {
            throw new EditionAlreadyExists("Já existe uma edição com esse nome.");
        }

    }

    /**
     * *
     * Elimina uma edição do array de edições . Procura pelo nome da edição para
     * verificar se ela existe, caso existe percorre o array e move o array em
     * uma posição para que este apague a edição. No fim decrementa o numero de
     * edições e transforma a ultima posição antes ocupada em null para retirar
     * qualquer dado que exista
     *
     * @param edName Nome da edição a eliminar
     */
    @Override
    public void deleteEditon(String edName) {
        int pos = findEditionByName(edName);
        if (pos == -1) {
            System.out.println("Edição não encontrada.");
        } else {
            for (int i = pos; i < this.numEditions - 1; i++) {
                this.editions[i] = this.editions[i + 1];
            }
            this.numEditions--;
            this.editions[numEditions] = null;
        }
    }

    /**
     * *
     * Lista todas as edições pelo método toString.
     */
    public void listEditions() {
        for (Edition ed : this.editions) {
            if (ed != null) {
                System.out.println(ed.toString());
            }
        }
    }

    /**
     *
     * Lista as edições que possuem projetos com submissões em falta em tarefas.
     *
     * @return o array com as edições
     * @throws EditionsWithoutSubmissionsCompleted caso não existam submissões
     * em falta
     */
    public Edition[] getEditionsWithMissingSubmissions() throws EditionsWithoutSubmissionsCompleted {
        Edition[] edtns = new Edition[editions.length];
        int index = 0;
        for (Edition ed : editions) {
            if (ed != null) {
                Project[] projects = ed.getProjects();
                for (Project proj : projects) {
                    if (proj != null) {
                        if (proj.isCompleted() == false) {
                            edtns[index] = ed;
                            index++;
                        }
                    }

                }
            }
        }
        if (index == 0) {
            throw new EditionsWithoutSubmissionsCompleted("Sem submissões em falta");
        } else {
            return edtns;
        }

    }

    /**
     * Procura uma Instituição pelo nome nos projetos das edições.
     *
     * @param name o nome da Instituição a ser procurada
     * @return a Instituição encontrada
     * @throws InstituitionNotFound se a Instituição não for encontrada nos
     * projetos das edições
     */
    public Instituition findInstituition(String name) throws InstituitionNotFound {
        for (Edition e : this.editions) {
            if (e != null) {
                for (Project p : e.getProjects()) {
                    if (p != null) {
                        if (p instanceof ProjectImpl) {
                            ProjectImpl pImpl = (ProjectImpl) p;
                            if (pImpl.findInstituition(name) != null) {
                                System.out.println("Instituição encontrada.");
                                return pImpl.findInstituition(name);
                            }
                        }
                    }
                }
            }
        }
        throw new InstituitionNotFound();
    }

    /////////////////////////listagens/////////////////////////////////////////
    /**
     * *
     * Lista as edições com o maior número de projetos
     *
     */
    public void listEditionWithMoreProjects() {
        int maxNumProjects = 0;
        int topProject = 0;
        if (this.numEditions == 0) {
            System.out.println("Ainda não existem edições.");
        } else {
            for (int i = 0; i < 10; i++) {

                for (int j = 0; j < this.numEditions; j++) {
                    if (i == 0) {
                        if (this.editions[j].getNumberOfProjects() > maxNumProjects) {
                            maxNumProjects = this.editions[j].getNumberOfProjects();
                        }
                    } else {
                        if (this.editions[j].getNumberOfProjects() > maxNumProjects && this.editions[j].getNumberOfProjects() < topProject) {
                            maxNumProjects = this.editions[j].getNumberOfProjects();
                        }
                    }
                }
                for (Edition ed : this.editions) {
                    if (ed != null) {
                        if (ed.getNumberOfProjects() == maxNumProjects && maxNumProjects != topProject) {
                            System.out.println(i + 1 + "º");
                            System.out.println("\nNúmero de projetos: " + maxNumProjects);
                            System.out.println(ed.toString());
                        }
                    }
                }
                topProject = maxNumProjects;
            }
        }
    }

    /**
     * Lista as edições com o maior número de participantes
     */
    public void listEditionWithMoreParticipants() {
        int maxNumParticipants = 0;
        int topParticipants = 0;
        int numParticipants = 0;
        if (this.numEditions == 0) {
            System.out.println("Ainda não existem edições.");
        } else {
            for (int i = 0; i < 10; i++) {

                for (int j = 0; j < this.numEditions; j++) {
                    numParticipants = 0;
                    for (Project p : this.editions[j].getProjects()) {
                        if (p != null) {
                            numParticipants += p.getNumberOfParticipants();
                        }
                    }
                    if (i == 0) {
                        if (numParticipants > maxNumParticipants) {
                            maxNumParticipants = numParticipants;
                        }
                    } else {
                        if (numParticipants > maxNumParticipants && numParticipants < topParticipants) {
                            maxNumParticipants = numParticipants;
                        }
                    }
                }
                for (Edition ed : this.editions) {
                    numParticipants = 0;
                    if (ed != null) {
                        for (Project p : ed.getProjects()) {
                            if (p != null) {
                                numParticipants += p.getNumberOfParticipants();
                            }
                        }
                        if (numParticipants == maxNumParticipants && maxNumParticipants != topParticipants) {
                            System.out.println(i + 1 + "º");
                            System.out.println("\nNúmero de participantes: " + maxNumParticipants);
                            System.out.println(ed.toString());
                        }
                    }
                }
                topParticipants = maxNumParticipants;
            }
        }
    }

}
