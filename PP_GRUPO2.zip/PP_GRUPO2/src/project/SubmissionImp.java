/* 
* Nome: Duarte Morais de Sousa
* Número: 8220160
* Turma: LEI12T4
* 
* Nome: André Eduardo Araújo Faria 
* Número: 8220787
* Turma: LEI12T2
*/

package project;
import java.io.Serializable;
import java.time.LocalDateTime;
import ma02_resources.participants.Student;
import ma02_resources.project.Submission;


public class SubmissionImp implements Submission,Serializable{
    
    private LocalDateTime date;
    private Student student;
    private String text;

    public SubmissionImp() {
    }
    
    public SubmissionImp(LocalDateTime date, Student student, String text) {
        this.date = date;
        this.student = student;
        this.text = text;
    }
    
    /***
     * Metodo toString que permite passar todos os dados de  uma submissão para Strings
     *  
     * @return string com informações de submissão
     */
    @Override
    public String toString() {
        String s="\n----------Submissão----------";
        s+= "\nTexto: " + this.text;
        s+= "\nAluno : " + this.student;
        s+= "\nData : " + this.date;
        return s;
    }
    

    /***
     * Obtem data de uma submissão.
     * @return data de uma Submissão.
     */
    @Override
    public LocalDateTime getDate() {
        return date;
    }

    /***
     * Define a data uma submissão. 
     * @param date a definir a submissão.
     */
    public void setDate(LocalDateTime date) {
        this.date = date;
    }

    /***
     * Obtem a memoria de um aluno em especifico.Esse aluno contem o 
     * numero que o define e os atributos da super classe 
     * Participant(nome, email e contacto)
     * @return Ao aluno pedido.
     */
    @Override
    public Student getStudent() {
        return student;
    }
    
    /***
     * Define o estudante que fez a submissão
     * 
     * 
     * @param student estudante que faz a submissão
     */
    public void setStudent(Student student) {
        this.student = student;
    }

    /***
     * Obtem o texto de uma submissao.
     * @return texto da submissao.
     */
    @Override
    public String getText() {
        return text;
    }

    /***
     * Define o texto de uma submissão.
     * @param text a ser definido na submissão
     */
    public void setText(String text) {
        this.text = text;
    }
    
    /***
     * Método que compara as datas de duas submissões para 
     * analisar qual é a mais recente ou mais antiga.
     * @param sbmsn submissão a comparar
     * @return 0 caso forem do mesmo dia, 1 caso a data da submissao for mais recente 
     * que a submissao a comparar e -1 caso contrário.
     */
    @Override
    public int compareTo(Submission sbmsn){
        if (this.getDate().isEqual(sbmsn.getDate()) ){
            return 0;
        } else if (this.getDate().isAfter(sbmsn.getDate())) {
            return 1;
        } else {
            return -1;
        }
    }
    
    
}
