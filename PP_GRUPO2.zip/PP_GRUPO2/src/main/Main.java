/* 
* Nome: Duarte Morais de Sousa
* Número: 8220160
* Turma: LEI12T4
* 
* Nome: André Eduardo Araújo Faria 
* Número: 8220787
* Turma: LEI12T2
 */
package main;

import Exceptions.EditionAlreadyExists;
import Exceptions.EditionNotFound;
import Exceptions.InstituitionNotFound;
import Exceptions.NotAStudent;
import Exceptions.TagAlreadyInProject;
import java.io.IOException;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import ma02_resources.participants.Student;
import ma02_resources.project.exceptions.IllegalNumberOfParticipantType;
import ma02_resources.project.exceptions.ParticipantAlreadyInProject;
import ma02_resources.project.exceptions.TaskAlreadyInProject;
import participants.ContactImpl;
import participants.FacilitatorImpl;
import participants.InstituitionImpl;
import participants.ParticipantImpl;
import participants.PartnerImpl;
import participants.StudentImpl;
import project.EditionImpl;
import project.EditionManagementImpl;
import project.ProjectImpl;
import project.SubmissionImp;
import project.TaskImp;

public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        EditionManagementImpl management = new EditionManagementImpl();
        int opt = 0;
        String nome;
        String descricao;
        LocalDate data;
        int num;

        do {
            System.out.println("Pretende utilizar dados guardados?");
            System.out.println("1.Sim");
            System.out.println("2.Não");
            opt = Input.inputInt();
            if (opt == 1) {
                try {
                    management = Input.readData();
                } catch (IOException ex) {
                    System.out.println("Erro de leitura de dados guardados. Experimente reiniciar o programa.");
                } catch (ClassNotFoundException ex) {
                    System.out.println("Erro de leitura de dados guardados.");
                }
            } else if (opt != 2) {
                System.out.println("Opção inválida.");
                opt = 0;
            }
        } while (opt == 0);

        do {
            //menu inicial
            opt = management.managementMenu();

            switch (opt) {
                case 0:
                    break;
                case 1:
                    System.out.println("Insira o nome da edição:");
                    nome = Input.inputStr();
                    do {
                        System.out.println("Insira a data de início da edição:");
                        data = Input.inputDate();
                        if (data.isBefore(LocalDate.now())) {
                            System.out.println("Data de início inválida.");
                        }
                    } while (data.isBefore(LocalDate.now()));
                    EditionImpl edition = new EditionImpl(nome, data);
                    try {
                        management.addEdition(edition);
                    } catch (EditionAlreadyExists exc) {
                        System.out.println("Edição já existe");
                    }
                    break;
                case 2:
                    System.out.println("Insira o nome da edição que pretende eliminar.");
                    nome = Input.inputStr();
                    management.deleteEditon(nome);
                    break;
                case 3:
                    System.out.println("Insira o nome da edição que pretende definir como ativa.");
                    nome = Input.inputStr();
                    management.setActiveEdition(nome);
                    break;
                case 4:
                    management.listEditions();
                    break;
                case 5:
                    System.out.println("Insira o nome da edição que pretende selecionar.");
                    nome = Input.inputStr();
                    EditionImpl selectedEdition;
                    try {
                        selectedEdition = (EditionImpl) management.getEdition(nome);
                    } catch (EditionNotFound exc) {
                        System.out.println(exc.getMessage());
                        break;
                    } catch (ClassCastException exc) {
                        System.out.println("Edição inválida.");
                        break;
                    }
                    do {
                        //menu de edição
                        selectedEdition.editionMenu();
                        opt = Input.inputInt();
                        switch (opt) {
                            case 1:
                                System.out.println("Insira o nome do projeto.");
                                nome = Input.inputStr();
                                System.out.println("Insira a descrição.");
                                descricao = Input.inputStr();
                                System.out.println("Insira uma tag.");
                                String[] tag = new String[1];
                                tag[0] = Input.inputStr();
                                try {
                                    selectedEdition.addProject(nome, descricao, tag);
                                } catch (IOException ex) {
                                    System.out.println(ex.getMessage());
                                } catch (ParseException ex) {
                                    System.out.println(ex.getMessage());
                                } catch (IllegalArgumentException ex) {
                                    System.out.println(ex.getMessage());
                                }
                                break;

                            case 2:
                                System.out.println("Insira o nome do projeto que pretende remover.");
                                nome = Input.inputStr();
                                try {
                                    selectedEdition.removeProject(nome);
                                } catch (Exception exc) {
                                    System.out.println(exc.getMessage());
                                }
                                break;
                            case 3:
                                selectedEdition.listProjects();
                                break;
                            case 4:
                                System.out.println("Insira o nome do projeto que pretende selecionar.");
                                nome = Input.inputStr();
                                ProjectImpl selectedProject;
                                try {
                                    selectedProject = (ProjectImpl) selectedEdition.getProject(nome);
                                } catch (IllegalArgumentException exc) {
                                    System.out.println(exc.getMessage());
                                    break;
                                } catch (ClassCastException exc) {
                                    System.out.println("Projeto inválido.");
                                    break;
                                }

                                do {
                                    //menu de projeto
                                    selectedProject.projectMenu();
                                    opt = Input.inputInt();
                                    switch (opt) {
                                        case 1:
                                            do {
                                                //menu de tarefa
                                                selectedProject.taskManagementMenu();
                                                opt = Input.inputInt();
                                                switch (opt) {
                                                    case 1:
                                                        System.out.println("Insira o título da tarefa.");
                                                        nome = Input.inputStr();
                                                        System.out.println("Insira a descrição da tarefa.");
                                                        descricao = Input.inputStr();
                                                        System.out.println("Insira a data de início.");
                                                        data = Input.inputDate();
                                                        System.out.println("Insira a duração em dias.");
                                                        num = Input.inputInt();
                                                        try {
                                                            selectedProject.addTask(new TaskImp(nome, descricao, data, num));
                                                        } catch (TaskAlreadyInProject exc) {
                                                            System.out.println(exc.getMessage());
                                                        }
                                                        break;
                                                    case 2:
                                                        selectedProject.listTasks();
                                                        break;
                                                    case 3:
                                                        TaskImp selectedTask;
                                                        System.out.println("Insira o título da tarefa que pretende selecionar.");
                                                        nome = Input.inputStr();
                                                        try {
                                                            selectedTask = (TaskImp) selectedProject.getTask(nome);
                                                        } catch (IllegalArgumentException exc) {
                                                            System.out.println(exc.getMessage());
                                                            break;
                                                        }
                                                        //menu da tarefa
                                                        do {
                                                            selectedTask.taskMenu();
                                                            opt = Input.inputInt();
                                                            switch (opt) {
                                                                case 1:
                                                                    System.out.println("Insira o seu email.");
                                                                    nome = Input.inputStr();
                                                                    Student student;
                                                                    try {
                                                                        student = selectedProject.findStudent(nome);
                                                                    } catch (IllegalArgumentException exc) {
                                                                        System.out.println("Estudante não encontrado.");
                                                                        break;
                                                                    } catch (NotAStudent exc) {
                                                                        System.out.println(exc.getMessage());
                                                                        break;
                                                                    }
                                                                    System.out.println("Insira o texto da submissão.");
                                                                    descricao = Input.inputStr();
                                                                    selectedTask.addSubmission(new SubmissionImp(LocalDateTime.now(), student, descricao));
                                                                    break;
                                                                case 2:
                                                                    selectedTask.listSubmissions();
                                                                    break;
                                                                case 3:
                                                                    System.out.println("Insira o número de dias que pretende adicionar à duração da tarefa.");
                                                                    num = Input.inputInt();
                                                                    try {
                                                                        selectedTask.extendDeadline(num);
                                                                    } catch (IllegalArgumentException exc) {
                                                                        System.out.println(exc.getMessage());
                                                                    }
                                                                    break;
                                                                case 4:
                                                                    break;
                                                                default:
                                                                    System.out.println("Opção inválida.");
                                                            }
                                                        } while (opt != 4);
                                                        opt = 3;
                                                        break;

                                                    case 4:
                                                        break;
                                                    default:
                                                        System.out.println("Opção inválida.");
                                                }
                                            } while (opt != 4);
                                            opt = 1;
                                            break;
                                        case 2:
                                            do {
                                                //menu de gestão de participantes
                                                selectedProject.participantManagementMenu();
                                                opt = Input.inputInt();
                                                switch (opt) {
                                                    case 1:
                                                        System.out.println("Insira o nome do participante");
                                                        nome = Input.inputStr();
                                                        System.out.println("Insira o email.");
                                                        descricao = Input.inputStr();
                                                        do {
                                                            System.out.println("Que tipo de participante pretende adicionar?");
                                                            System.out.println("1.Estudante");
                                                            System.out.println("2.Facilitador");
                                                            System.out.println("3.Parceiro");
                                                            opt = Input.inputInt();
                                                            if (opt < 1 || opt > 3) {
                                                                System.out.println("Opção inválida.");
                                                            }
                                                        } while (opt < 1 || opt > 3);
                                                        switch (opt) {
                                                            case 1:
                                                                System.out.println("Insira o número de estudante.");
                                                                opt = Input.inputInt();
                                                                StudentImpl s = new StudentImpl(nome, descricao, new ContactImpl(), opt);
                                                                System.out.println("Insira o nome da instituição.");
                                                                nome = Input.inputStr();
                                                                try {
                                                                    s.setInstituition(management.findInstituition(nome));
                                                                } catch (InstituitionNotFound ex) {
                                                                    s.setInstituition(new InstituitionImpl(nome));
                                                                }
                                                                try {
                                                                    selectedProject.addParticipant(s);
                                                                } catch (ParticipantAlreadyInProject ex) {
                                                                    System.out.println(ex.getMessage());
                                                                } catch (IllegalNumberOfParticipantType ex) {
                                                                    System.out.println(ex.getMessage());
                                                                }
                                                                opt = 1;
                                                                break;
                                                            case 2:
                                                                System.out.println("Insira a sua área de especialização.");
                                                                FacilitatorImpl f = new FacilitatorImpl(nome, descricao, Input.inputStr(), new ContactImpl());
                                                                System.out.println("Insira o nome da instituição.");
                                                                nome = Input.inputStr();
                                                                try {
                                                                    f.setInstituition(management.findInstituition(nome));
                                                                } catch (InstituitionNotFound ex) {
                                                                    f.setInstituition(new InstituitionImpl(nome));
                                                                }
                                                                try {
                                                                    selectedProject.addParticipant(f);
                                                                } catch (ParticipantAlreadyInProject ex) {
                                                                    System.out.println(ex.getMessage());
                                                                } catch (IllegalNumberOfParticipantType ex) {
                                                                    System.out.println(ex.getMessage());
                                                                }
                                                                break;
                                                            case 3:
                                                                System.out.println("Insira o nif do parceiro.");
                                                                String vat = Input.inputStr();
                                                                System.out.println("Insira o website do parceiro.");
                                                                PartnerImpl p = new PartnerImpl(nome, descricao, vat, Input.inputStr(), new ContactImpl());
                                                                System.out.println("Insira o nome da instituição.");
                                                                nome = Input.inputStr();
                                                                try {
                                                                    p.setInstituition(management.findInstituition(nome));
                                                                } catch (InstituitionNotFound ex) {
                                                                    p.setInstituition(new InstituitionImpl(nome));
                                                                }
                                                                try {
                                                                    selectedProject.addParticipant(p);
                                                                } catch (ParticipantAlreadyInProject ex) {
                                                                    System.out.println(ex.getMessage());
                                                                } catch (IllegalNumberOfParticipantType ex) {
                                                                    System.out.println(ex.getMessage());
                                                                }
                                                                break;
                                                        }
                                                        opt = 1;
                                                        break;
                                                    case 2:
                                                        System.out.println("Insira o email do participante que pretende remover.");
                                                        nome = Input.inputStr();
                                                        try {
                                                            selectedProject.removeParticipant(nome);
                                                        } catch (IllegalArgumentException exc) {
                                                            System.out.println(exc.getMessage());
                                                        }
                                                        break;
                                                    case 3:
                                                        selectedProject.listParticipants();
                                                        break;
                                                    case 4:
                                                        System.out.println("Insira email do participante que pretende selecionar.");
                                                        nome = Input.inputStr();
                                                        ParticipantImpl selectedParticipant;
                                                        try {
                                                            selectedParticipant = (ParticipantImpl) selectedProject.getParticipant(nome);
                                                        } catch (IllegalArgumentException exc) {
                                                            System.out.println(exc.getMessage());
                                                            break;
                                                        }
                                                        //menu participante 
                                                        do {
                                                            selectedParticipant.participantMenu();
                                                            opt = Input.inputInt();
                                                            switch (opt) {
                                                                case 1:
                                                                    System.out.println(selectedParticipant.getContact().toString());
                                                                    break;
                                                                case 2:
                                                                    System.out.println(selectedParticipant.getInstituition().toString());
                                                                    break;
                                                                case 3:
                                                                    break;
                                                                default:
                                                                    System.out.println("Opção inválida.");
                                                            }
                                                        } while (opt < 1 || opt > 3);
                                                        opt = 4;
                                                        break;
                                                    case 5:
                                                        break;
                                                    default:
                                                        System.out.println("Opção inválida.");
                                                }
                                            } while (opt != 5);
                                            opt = 2;
                                            break;
                                        case 3:
                                            do {
                                                selectedProject.tagsManagementMenu();
                                                opt = Input.inputInt();
                                                switch (opt) {
                                                    case 1:
                                                        System.out.println("Insira a tag que pretende adicionar.");
                                                        nome = Input.inputStr();
                                                        try {
                                                            selectedProject.addTag(nome);
                                                        } catch (TagAlreadyInProject ex) {
                                                            System.out.println(ex.getMessage());
                                                        }
                                                        break;
                                                    case 2:
                                                        System.out.println("Insira a tag que pretende remover.");
                                                        nome = Input.inputStr();
                                                        selectedProject.deleteTag(nome);
                                                        break;
                                                    case 3:
                                                        selectedProject.listTags();
                                                        break;
                                                    case 4:
                                                        break;
                                                    default:
                                                        System.out.println("Opção inválida.");
                                                }
                                            } while (opt != 4);
                                            opt = 3;
                                            break;
                                        case 4:
                                            selectedProject.listClosestDeadlineTasks();
                                            break;
                                        case 5:
                                            break;
                                        default:
                                            System.out.println("Opção inválida.");
                                    }

                                } while (opt != 5);
                                opt = 4;
                                break;
                            case 5:
                                break;
                            default:
                                System.out.println("Opção inválida");
                        }

                    } while (opt != 5);
                    opt = 5;
                    break;
                case 6:
                    management.listEditionWithMoreParticipants();
                    break;
                case 7:
                    management.listEditionWithMoreProjects();
                    break;
                case 8:
                    try {
                    Input.saveData(management);
                } catch (IOException ex) {
                    System.out.println("Erro ao guardar dados.");
                }
                break;
                case 9:
                    break;
                default:
                    System.out.println("Opção inválida.");
            }

        } while (opt != 9);
    }

}
