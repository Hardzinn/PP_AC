/* 
* Nome: Duarte Morais de Sousa
* Número: 8220160
* Turma: LEI12T4
* 
* Nome: André Eduardo Araújo Faria 
* Número: 8220787
* Turma: LEI12T2
 */
package main;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import project.EditionManagementImpl;

public abstract class Input {

    /**
     * Este método permite que o utilizador faça input de um inteiro na consola,
     * fazendo catch das exceções possíveis
     *
     * @return inteiro inserido pelo utilizador, no caso de haver alguma
     * exceção: 0
     */
    public static int inputInt() {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String str;
        int opt;
        try {
            str = br.readLine();
            opt = Integer.parseInt(str);
        } catch (IOException ex) {
            opt = 0;
            System.out.println("Erro de input.");
        } catch (NumberFormatException ex) {
            opt = 0;
            System.out.println("Valor inválido.");
        }
        return opt;
    }

    /**
     * Este método permite que o utilizador faça input de uma string na consola,
     * fazendo catch das exceções possíveis
     *
     * @return string inserida pelo utilizador
     *
     */
    public static String inputStr() {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String str;
        try {
            str = br.readLine();
        } catch (IOException ex) {
            str = " ";
            System.out.println("Erro de input.");
        }
        return str;
    }

    /**
     * Este método permite que o utilizador faça input de uma data na consola,
     * fazendo catch das exceções possíveis
     *
     * @return data inserida pelo utilizador
     *
     */
    public static LocalDate inputDate() {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int dia = 0;
        int mes = 0;
        int ano = 0;
        LocalDate data;
        System.out.println("Insira o dia:");
        dia = inputInt();
        System.out.println("Insira o mês:");
        mes = inputInt();
        System.out.println("Insira o ano.");
        ano = inputInt();
        data = LocalDate.of(ano, mes, dia);
        return data;
    }

    /**
     * Este método permite guardar os dados de uma gestão de edições num
     * ficheiro txt
     *
     * @param edm gestão de edições a guardar
     * @throws IOException caso ao guardar os dados, o ficheiro não for criado
     */
    public static void saveData(EditionManagementImpl edm) throws IOException {
        ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("./Data.txt"));

        out.writeObject(edm);
    }

    /**
     * Este método permite ler os dados de uma gestão de edições num ficheiro
     * txt
     *
     * @return gestão de edições
     * @throws IOException Caso o ficheiro não seja encontrado
     * @throws ClassNotFoundException Caso os dados guardados não coincidam com os que devem ser lidos
     */
    public static EditionManagementImpl readData() throws IOException, ClassNotFoundException {
        ObjectInputStream in = new ObjectInputStream(new FileInputStream("./Data.txt"));

        EditionManagementImpl edm = (EditionManagementImpl) in.readObject();

        return edm;
    }
}
