/* 
* Nome: Duarte Morais de Sousa
* Número: 8220160
* Turma: LEI12T4
* 
* Nome: André Eduardo Araújo Faria 
* Número: 8220787
* Turma: LEI12T2
 */
package participants;

import java.io.Serializable;
import ma02_resources.participants.Contact;
import ma02_resources.participants.Instituition;
import ma02_resources.participants.InstituitionType;
import main.Input;

public class InstituitionImpl implements Instituition, Serializable {

    private String name;
    private String email;
    private InstituitionType type;
    private Contact contact;
    private String website;
    private String description;

    public InstituitionImpl(String nome) {
        int opt;
        this.name = nome;
        System.out.println("Insira o email da instituição.");
        this.email = Input.inputStr();
        System.out.println("Insira o website da instituição.");
        this.website = Input.inputStr();
        System.out.println("Insira a descrição da instituição.");
        this.description = Input.inputStr();
        do {
            System.out.println("Tipo de instituição:");
            System.out.println("1.Universidade");
            System.out.println("2.Empresa");
            System.out.println("3.Organização não governamental");
            System.out.println("4.Outro");
            opt = Input.inputInt();
            switch (opt) {
                case 1:
                    this.type = InstituitionType.UNIVERSITY;
                    break;
                case 2:
                    this.type = InstituitionType.COMPANY;
                    break;
                case 3:
                    this.type = InstituitionType.NGO;
                    break;
                case 4:
                    this.type = InstituitionType.OTHER;
                    break;
                default:
                    System.out.println("Opção inválida.");
            }
        } while (opt < 1 || opt > 4);
        System.out.println("Contacto da instituição:");
        this.contact = new ContactImpl();

    }

    public InstituitionImpl() {
        int opt;
        System.out.println("Insira o nome da instituição.");
        this.name = Input.inputStr();
        System.out.println("Insira o email da instituição.");
        this.email = Input.inputStr();
        System.out.println("Insira o website da instituição.");
        this.website = Input.inputStr();
        System.out.println("Insira a descrição da instituição.");
        this.description = Input.inputStr();
        do {
            System.out.println("Tipo de instituição:");
            System.out.println("1.Universidade");
            System.out.println("2.Empresa");
            System.out.println("3.Organização não governamental");
            System.out.println("4.Outro");
            opt = Input.inputInt();
            switch (opt) {
                case 1:
                    this.type = InstituitionType.UNIVERSITY;
                    break;
                case 2:
                    this.type = InstituitionType.COMPANY;
                    break;
                case 3:
                    this.type = InstituitionType.NGO;
                    break;
                case 4:
                    this.type = InstituitionType.OTHER;
                    break;
                default:
                    System.out.println("Opção inválida.");
            }
        } while (opt < 1 || opt > 4);
        System.out.println("Contacto da empresa:");
        this.contact = new ContactImpl();

    }

    private InstituitionImpl(String name, String email) {
        this.name = name;
        this.email = email;
    }

    /**
     * Este método cria uma String que representa as informações de uma
     * instituição
     *
     * @return String com informações relativas à instituição
     */
    @Override
    public String toString() {
        String s = "";
        s += "\nNome: " + this.name;
        s += "\nEmail: " + this.email;
        s += "\nTipo de instituição: " + this.type.toString();
        s += "\nWebsite: " + this.website;
        s += "\nDescrição: " + this.description;
        s += "\nContacto: " + this.contact.toString();
        return s;
    }

    /**
     * Método getter para o nome da instituição
     *
     * @return nome
     */
    @Override
    public String getName() {
        return this.name;
    }

    /**
     * Método getter para o email da instituição
     *
     * @return email
     */
    @Override
    public String getEmail() {
        return this.email;
    }

    /**
     * Método getter para o tipo de instituição
     *
     * @return tipo de instituição
     */
    @Override
    public InstituitionType getType() {
        return this.type;
    }

    /**
     * Método getter para o contacto da instituição
     *
     * @return contacto
     */
    @Override
    public Contact getContact() {
        return this.contact;
    }

    /**
     * Método getter para o website da instituição
     *
     * @return website
     */
    @Override
    public String getWebsite() {
        return this.website;
    }

    /**
     * Método getter para a descrição da instituição
     *
     * @return descrição
     */
    @Override
    public String getDescription() {
        return this.description;
    }

    /**
     * Método setter para o website da instituição
     *
     * @param string website
     */
    @Override
    public void setWebsite(String string) {
        this.website = string;
    }

    /**
     * Método setter para a descrição da instituição
     *
     * @param string descrição
     */
    @Override
    public void setDescription(String string) {
        this.description = string;
    }

    /**
     * Método setter para o contacto da instituição
     *
     * @param cntct contacto
     */
    @Override
    public void setContact(Contact cntct) {
        //usar clone
        this.contact = cntct;
    }

    /**
     * Método setter para o tipo da instituição
     *
     * @param it tipo de instituição
     */
    @Override
    public void setType(InstituitionType it) {
        this.type = it;
    }

    /**
     * Este método descobre se dois facilitadores são iguais
     *
     * @param obj facilitador para comparar com o atual(this)
     * @return true se ambos forem iguais; false se forem diferentes;
     */
    @Override
    public boolean equals(Object obj) {
        if (obj instanceof InstituitionImpl == false) {
            return false;
        }
        InstituitionImpl objToCheck = (InstituitionImpl) obj;
        if (objToCheck.name != this.name) {
            return false;
        }
        if (objToCheck.email != this.email) {
            return false;
        }
        if (objToCheck.type != this.type) {
            return false;
        }
        if (objToCheck.contact.equals(this.contact) == false) {
            return false;
        }
        if (objToCheck.website != this.website) {
            return false;
        }
        if (objToCheck.description != this.description) {
            return false;
        }

        return true;
    }

}
