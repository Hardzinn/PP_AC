/* 
* Nome: Duarte Morais de Sousa
* Número: 8220160
* Turma: LEI12T4
* 
* Nome: André Eduardo Araújo Faria 
* Número: 8220787
* Turma: LEI12T2
 */
package participants;

import java.io.Serializable;
import ma02_resources.participants.Contact;
import ma02_resources.participants.Facilitator;

public class FacilitatorImpl extends ParticipantImpl implements Facilitator,Serializable {

    private String areaOfExpertise;

    public FacilitatorImpl(String name, String email, String areaOfExpertise, Contact contact) {
        super(name, email, contact);
        this.areaOfExpertise = areaOfExpertise;
    }

    /**
     * Este método cria uma String que representa as informações de um
     * facilitador
     *
     * @return String com informações relativas ao facilitador
     */
    @Override
    public String toString() {
        String s = super.toString();
        s += "\nTipo de participante: Facilitador";
        s += "\nÁrea de especialização: " + this.areaOfExpertise;
        return s;
    }

    /**
     * Método getter para a área de especialização
     *
     * @return área de especialização
     */
    @Override
    public String getAreaOfExpertise() {
        return this.areaOfExpertise;
    }

    /**
     * Método setter para a área de especialização
     *
     * @param string área de especialização
     */
    @Override
    public void setAreaOfExpertise(String string) {
        this.areaOfExpertise = string;
    }

    /**
     * Este método descobre se dois facilitadores são iguais
     *
     * @param o facilitador para comparar com o atual(this)
     * @return true se ambos forem iguais; false se forem diferentes;
     */
    @Override
    public boolean equals(Object o) {
        if (super.equals(o) == false) {
            return false;
        }

        if (o instanceof FacilitatorImpl == false) {
            return false;
        }
        FacilitatorImpl obj = (FacilitatorImpl) o;
        if (this.areaOfExpertise != obj.getAreaOfExpertise()) {
            return false;
        }

        return true;
    }
}
