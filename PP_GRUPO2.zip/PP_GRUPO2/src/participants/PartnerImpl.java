/* 
* Nome: Duarte Morais de Sousa
* Número: 8220160
* Turma: LEI12T4
* 
* Nome: André Eduardo Araújo Faria 
* Número: 8220787
* Turma: LEI12T2
 */
package participants;

import java.io.Serializable;
import ma02_resources.participants.Contact;
import ma02_resources.participants.Partner;

public class PartnerImpl extends ParticipantImpl implements Partner,Serializable {

    private String vat;
    private String website;

    public PartnerImpl(String name, String email, String vat, String website, Contact contact) {
        super(name, email, contact);
        this.vat = vat;
        this.website = website;
    }

    /**
     * Este método cria uma String que representa as informações de um parceiro
     *
     *
     * @return String com informações relativas ao parceiro
     */
    @Override
    public String toString() {
        String s = super.toString();
        s += "\nTipo de participante: Parceiro";
        s += "\nNIF: " + this.vat;
        s += "\nWebsite: " + this.website;
        return s;
    }

    /**
     * Método getter para o NIF do parceiro
     *
     * @return NIF do parceiro
     */
    @Override
    public String getVat() {
        return this.vat;
    }

    /**
     * Método getter para o website do parceiro
     *
     * @return website do parceiro
     */
    @Override
    public String getWebsite() {
        return this.website;
    }
}
