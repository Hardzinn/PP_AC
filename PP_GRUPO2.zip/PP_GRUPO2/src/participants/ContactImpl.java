/* 
* Nome: Duarte Morais de Sousa
* Número: 8220160
* Turma: LEI12T4
* 
* Nome: André Eduardo Araújo Faria 
* Número: 8220787
* Turma: LEI12T2
 */
package participants;

import java.io.Serializable;
import ma02_resources.participants.Contact;
import main.Input;

public class ContactImpl implements Contact, Serializable {

    private String street;
    private String city;
    private String state;
    private String zipCode;
    private String country;
    private int phone;

    public ContactImpl() {
        System.out.println("Insira o seu país.");
        this.country = Input.inputStr();
        System.out.println("Insira o seu estado/distrito.");
        this.state = Input.inputStr();
        System.out.println("Insira a sua cidade.");
        this.city = Input.inputStr();
        System.out.println("Insira a sua rua.");
        this.street = Input.inputStr();
        System.out.println("Insira o seu código postal.");
        this.zipCode = Input.inputStr();
        do {
            System.out.println("Insira o seu número de telefone.");
            this.phone = Input.inputInt();
            if (this.phone <= 99999999 || this.phone >= 1000000000) {
                System.out.println("Número inválido.Tente novamente.");
            }
        } while (this.phone <= 99999999 || this.phone >= 1000000000);

    }

    /**
     * Este método cria uma String que representa as informações de um contacto
     *
     * @return String com informações relativas ao contacto
     */
    @Override
    public String toString() {
        String s = "";
        s += "\nPaís: " + this.country;
        s += "\nEstado/Distrito: " + this.state;
        s += "\nCidade: " + this.city;
        s += "\nRua: " + this.street;
        s += "\nCódigo Postal: " + this.zipCode;
        s += "\nTelemóvel: " + this.phone;
        return s;
    }

    /**
     * Método getter para a rua
     *
     * @return rua
     */
    @Override
    public String getStreet() {
        return this.street;
    }

    /**
     * Método getter para a cidade
     *
     * @return cidade
     */
    @Override
    public String getCity() {
        return this.city;
    }

    /**
     * Método getter para o estado/distrito
     *
     * @return estado/distrito
     */
    @Override
    public String getState() {
        return this.state;
    }

    /**
     * Método getter para o código postal
     *
     * @return código postal
     */
    @Override
    public String getZipCode() {
        return this.zipCode;
    }

    /**
     * Método getter para o país
     *
     * @return país
     */
    @Override
    public String getCountry() {
        return this.country;
    }

    /**
     * Método getter para o número de telemóvel
     *
     * @return número de telemóvel
     */
    @Override
    public String getPhone() {
        String s = "" + this.phone;
        return s;
    }

    /**
     * Este método descobre se dois contactos são iguais
     *
     * @param obj contacto para comparar com o atual(this)
     * @return true se ambos forem iguais;false se forem diferentes;
     */
    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Contact == false) {
            return false;
        }
        Contact objToCheck = (Contact) obj;
        if (objToCheck.getStreet() != this.street) {
            return false;
        }
        if (objToCheck.getCity() != this.city) {
            return false;
        }
        if (objToCheck.getState() != this.state) {
            return false;
        }
        if (objToCheck.getZipCode() != this.zipCode) {
            return false;
        }
        if (objToCheck.getCountry() != this.country) {
            return false;
        }
        if (!objToCheck.getPhone().equals("" + this.phone)) {
            return false;
        }
        return true;
    }

}
