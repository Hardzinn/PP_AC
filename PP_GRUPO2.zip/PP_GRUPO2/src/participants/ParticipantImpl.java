/* 
* Nome: Duarte Morais de Sousa
* Número: 8220160
* Turma: LEI12T4
* 
* Nome: André Eduardo Araújo Faria 
* Número: 8220787
* Turma: LEI12T2
 */
package participants;

import java.io.Serializable;
import ma02_resources.participants.Contact;
import ma02_resources.participants.Instituition;
import ma02_resources.participants.Participant;

public abstract class ParticipantImpl implements Participant, Serializable {

    private String name;
    private String email;
    private Contact contact;
    private Instituition instituition;

    public ParticipantImpl(String name, String email, Contact contact) {
        this.name = name;
        this.email = email;
        this.contact = contact;
    }

    /**
     * Este método escreve na consola o menu relativo a um participante.
     */
    public void participantMenu() {
        System.out.println("-------------Menu de participante: " + this.name + "-------------");
        System.out.println("1.Contacto");
        System.out.println("2.Instituição");
        System.out.println("3.Voltar");
    }

    /**
     * Este método cria uma String que representa as informações de um
     * participante
     *
     * @return String com informações relativas ao participante
     */
    @Override
    public String toString() {
        String s = "\n----------Participante----------";
        s += "\nNome: " + this.name;
        s += "\nEmail: " + this.email;
        return s;
    }

    /**
     * Método getter para o nome do participante
     *
     * @return nome do participante
     */
    @Override
    public String getName() {
        return this.name;
    }

    /**
     * Método getter para o email do participante
     *
     * @return email do participante
     */
    @Override
    public String getEmail() {
        return this.email;
    }

    /**
     * Método getter para o contacto do participante
     *
     * @return contacto do participante
     */
    @Override
    public Contact getContact() {
        return this.contact;
    }

    /**
     * Método getter para a instituição do participante
     *
     * @return instituição do participante
     */
    @Override
    public Instituition getInstituition() {
        return this.instituition;
    }

    /**
     * Método setter para a instituição do participante
     *
     * @param instn instituição do participante
     */
    @Override
    public void setInstituition(Instituition instn) {
        this.instituition = instn; //usar clone?
    }

    /**
     * Método setter para o contacto do participante
     *
     * @param cntct contacto do participante
     */
    @Override
    public void setContact(Contact cntct) {
        this.contact = cntct; //usar clone?
    }

    /**
     * Este método descobre se dois participantes são iguais
     *
     * @param o participante para comparar com o atual(this)
     * @return true se ambos forem iguais; false se forem diferentes;
     */
    @Override
    public boolean equals(Object o) {
        if (o instanceof ParticipantImpl == false) {
            return false;
        }
        ParticipantImpl obj = (ParticipantImpl) o;
        if (obj.name != this.name) {
            return false;
        }
        if (obj.email != this.email) {
            return false;
        }
        if (obj.instituition != this.instituition) {
            return false;
        }
        if (obj.contact.equals(this.contact) == false) {
            return false;
        }
        return true;
    }

}
