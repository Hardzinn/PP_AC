/* 
* Nome: Duarte Morais de Sousa
* Número: 8220160
* Turma: LEI12T4
* 
* Nome: André Eduardo Araújo Faria 
* Número: 8220787
* Turma: LEI12T2
 */
package participants;

import java.io.Serializable;
import ma02_resources.participants.Contact;
import ma02_resources.participants.Student;

public class StudentImpl extends ParticipantImpl implements Student,Serializable {

    private int number;

    public StudentImpl(String name, String email, Contact contact, int number) {
        super(name, email, contact);
        this.number = number;
    }

    /**
     * Este método cria uma String que representa as informações de um estudante
     *
     *
     * @return String com informações relativas ao estudante
     */
    @Override
    public String toString() {
        String s = super.toString();
        s += "\nTipo de participante: Estudante";
        s += "\nNúmero de estudante: " + this.number;
        return s;
    }

    /**
     * Método getter para o número de estudante
     *
     * @return número de estudante
     */
    @Override
    public int getNumber() {
        return this.number;
    }

}
